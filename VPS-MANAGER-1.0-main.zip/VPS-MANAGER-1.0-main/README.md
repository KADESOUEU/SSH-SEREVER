
__VPS-MANAGER 1.0__

__Recomendado__
- Ubuntu 18

![logo](https://github.com/NT-GIT-HUB/VPS-MANAGER-1.0/blob/main/home.png)

__Instalar apenas o SCRIPT__

```wget https://raw.githubusercontent.com/NT-GIT-HUB/VPS-MANAGER-1.0/main/Plus; chmod 777 Plus;./Plus```

__Instalar o SCRIPT e atualizar pacotes do sistema__

```apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/NT-GIT-HUB/VPS-MANAGER-1.0/main/Plus; chmod 777 Plus;./Plus```

__Alterar senha Root__

```sudo -i```

```bash <(wget -qO- https://raw.githubusercontent.com/NT-GIT-HUB/VPS-MANAGER-1.0/main/senharoot.sh)```